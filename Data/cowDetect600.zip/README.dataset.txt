# cowDetect > 2022-07-26 9:37pm
https://universe.roboflow.com/object-detection/cowdetect-syie6

Provided by Roboflow
License: CC BY 4.0

