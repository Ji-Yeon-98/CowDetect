# cowDetect > 20220714
https://universe.roboflow.com/object-detection/cowdetect-syie6

Provided by Roboflow
License: CC BY 4.0

